const STORAGE_KEY = "rabtech-capstone-products";
const USER_KEY = "rabtech-capstone-user";

const starterProducts = [
  {id:1,name:"Wireless Headphones",category:"Electronics",price:79.99,description:"Comfortable wireless headphones for everyday use."},
  {id:2,name:"JavaScript Handbook",category:"Books",price:29.50,description:"A practical guide to modern JavaScript development."},
  {id:3,name:"Desk Lamp",category:"Home",price:34.90,description:"Compact LED desk lamp with adjustable brightness."},
  {id:4,name:"Everyday Backpack",category:"Fashion",price:49.00,description:"Lightweight backpack for study and work."}
];

let products = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null") || starterProducts;
let currentUser = localStorage.getItem(USER_KEY) || "";

const catalog = document.querySelector("#catalog");
const search = document.querySelector("#search");
const category = document.querySelector("#category");
const status = document.querySelector("#status");
const authDialog = document.querySelector("#authDialog");
const productDialog = document.querySelector("#productDialog");

function persist(){localStorage.setItem(STORAGE_KEY, JSON.stringify(products));}
function renderCategories(){
  const values=[...new Set(products.map(p=>p.category))].sort();
  category.innerHTML='<option value="all">All categories</option>';
  values.forEach(value=>{
    const option=document.createElement("option");
    option.value=value; option.textContent=value; category.appendChild(option);
  });
}
function filtered(){
  const q=search.value.trim().toLowerCase();
  return products.filter(p=>(category.value==="all"||p.category===category.value)&&p.name.toLowerCase().includes(q));
}
function render(){
  catalog.innerHTML="";
  const items=filtered();
  items.forEach(product=>{
    const card=document.createElement("article"); card.className="card";
    const title=document.createElement("h2"); title.textContent=product.name;
    const cat=document.createElement("div"); cat.className="category"; cat.textContent=product.category;
    const price=document.createElement("div"); price.className="price"; price.textContent=`$${product.price.toFixed(2)}`;
    const desc=document.createElement("p"); desc.textContent=product.description;
    const actions=document.createElement("div"); actions.className="actions";
    const edit=document.createElement("button"); edit.textContent="Edit"; edit.type="button"; edit.addEventListener("click",()=>openEdit(product));
    const del=document.createElement("button"); del.textContent="Delete"; del.className="delete"; del.type="button"; del.addEventListener("click",()=>removeProduct(product.id));
    actions.append(edit,del); card.append(title,cat,price,desc,actions); catalog.append(card);
  });
  status.textContent=`${items.length} product${items.length===1?"":"s"} shown.`;
}
function updateUser(){
  document.querySelector("#userLabel").textContent=currentUser?`Signed in as ${currentUser}`:"Guest";
  document.querySelector("#authBtn").textContent=currentUser?"Sign out":"Sign in";
}
function openEdit(product){
  document.querySelector("#productTitle").textContent="Edit Product";
  document.querySelector("#productId").value=product.id;
  document.querySelector("#productName").value=product.name;
  document.querySelector("#productCategory").value=product.category;
  document.querySelector("#productPrice").value=product.price;
  document.querySelector("#productDescription").value=product.description;
  productDialog.showModal();
}
function removeProduct(id){
  if(!confirm("Delete this product?")) return;
  products=products.filter(p=>p.id!==id); persist(); renderCategories(); render();
}
document.querySelector("#authBtn").addEventListener("click",()=>{
  if(currentUser){currentUser="";localStorage.removeItem(USER_KEY);updateUser();return;}
  document.querySelector("#displayName").value=""; authDialog.showModal();
});
document.querySelector("#authForm").addEventListener("submit",e=>{
  e.preventDefault();
  currentUser=document.querySelector("#displayName").value.trim();
  if(currentUser){localStorage.setItem(USER_KEY,currentUser);updateUser();authDialog.close();}
});
document.querySelector("#addProductBtn").addEventListener("click",()=>{
  document.querySelector("#productTitle").textContent="Add Product";
  document.querySelector("#productForm").reset();
  document.querySelector("#productId").value="";
  productDialog.showModal();
});
document.querySelector("#cancelProduct").addEventListener("click",()=>productDialog.close());
document.querySelector("#productForm").addEventListener("submit",e=>{
  e.preventDefault();
  const id=document.querySelector("#productId").value;
  const data={
    id:id?Number(id):Date.now(),
    name:document.querySelector("#productName").value.trim(),
    category:document.querySelector("#productCategory").value,
    price:Number(document.querySelector("#productPrice").value),
    description:document.querySelector("#productDescription").value.trim()
  };
  if(id) products=products.map(p=>p.id===Number(id)?data:p);
  else products.unshift(data);
  persist(); renderCategories(); render(); productDialog.close();
});
search.addEventListener("input",render);
category.addEventListener("change",render);

updateUser();
renderCategories();
render();
