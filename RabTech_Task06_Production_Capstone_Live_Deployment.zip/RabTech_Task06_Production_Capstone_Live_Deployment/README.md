# RabTech Academy – Task 06
## Production Capstone Project & Live Deployment

### Capstone
**Interactive Product Catalog**

This project combines the internship skills into a deploy-ready web application.

### Features
- Simulated authentication with persistent browser state
- Interactive product catalog
- Search and category filtering
- Create, read, update and delete product operations
- Persistent product state using localStorage
- Responsive layout
- Accessible labels, focus states and live status updates
- No backend credentials or secrets required

### Architecture

```text
Browser
  |
  +-- index.html
  |
  +-- style.css
  |
  +-- app.js
        |
        +-- localStorage (products + simulated user)
```

### Local setup
No build step is required.

1. Download/clone the repository.
2. Open `index.html` in a browser.
3. Sign in using any display name.
4. Add, edit, search, filter and delete products.

### Deployment
This is a static web application and is ready to deploy to Vercel, Netlify, or Cloudflare Pages.

After deployment, add the actual public deployment URL to this README and submit:
- GitHub source-code repository URL
- Live deployment URL

### Important
A real public GitHub repository and live deployment require the user's own GitHub/cloud account. This package is the source code prepared for that final deployment step; no fake live URL is included.
